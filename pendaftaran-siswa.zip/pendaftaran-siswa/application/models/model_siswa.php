<?php
Class model_siswa extends CI_Model
{
    public $id;
    public $nama;
    public $alamat;
    public $jenis_kelamin;
    public $agama;
    public $sekolah_asal;

    public function get_all_data_siswa()
    {
        $query = "SELECT * FROM calon_siswa";
        return $this->db->query($query)->result_array();
    }

}
?>