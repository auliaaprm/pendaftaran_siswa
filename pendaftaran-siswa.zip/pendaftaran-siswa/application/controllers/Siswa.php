<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Siswa extends CI_Controller 
    {
    
        public function __construct()
        {
            parent::__construct();
            $this->load->helper('url');
            $this->load->model('model_siswa', 'ms');
    
        }
    
        public function index()
        {
            $data['title'] = "";
            $data['allsiswa'] = $this->ms->get_all_data_siswa();
    
            $this->load->view('data_siswa', $data);
        }

        public function siswa_create()
	{
        $data['title'] = "";

		$this->load->view('siswa_create', $data);
	}

    public function simpansiswa()
	{
		$data = [
			'nama' => $this->input->post('nama'),
			'alamat' => $this->input->post('alamat'),
			'jenis_kelamin' => $this->input->post('jenis_kelamin'),
			'agama' => $this->input->post('agama'),
			'sekolah_asal' => $this->input->post('sekolah_asal'),
		];
		$this->db->insert('calon_siswa', $data);

		return redirect()->to('data_siswa');
	}

    public function siswa_edit($id)
	{
		$data['title'] = "";
		$data['siswa'] = $this->db->get_where('calon_siswa', ['id' => $id])->row_array();

		$this->load->view('siswa_edit', $data);
	}

	public function editsiswa()
	{

		$this->db->set('nama', $this->input->post('nama'));
		$this->db->set('alamat', $this->input->post('alamat'));
		$this->db->set('jenis_kelamin', $this->input->post('jenis_kelamin'));
		$this->db->set('agama', $this->input->post('agama'));
		$this->db->set('sekolah_asal', $this->input->post('sekolah_asal'));
		$this->db->where('id', $this->input->post('id'));
		$this->db->update('calon_siswa');

		return redirect()->to('data_siswa');
	}

	public function hapus_siswa($id)
	{

		$this->db->where('id', $id);
		$this->db->delete('calon_siswa');

		return redirect()->to('data_siswa');
	}
}