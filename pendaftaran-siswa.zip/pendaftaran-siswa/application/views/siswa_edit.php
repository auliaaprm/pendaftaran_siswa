<?php

?>

<head>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <title>Data Matakuliah</title>
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #6a8bc5;">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Pendaftaran Siswa</a>

    </div>
  </div>
</nav>
<br>
<div class="container">
        <div class="card" style="width: 50rem;margin: auto;">
                    <div class="card-body">
                    <div class="d-sm-flex align-items-center justify-content-between">
                        <h1 class="h3 mb-0 text-gray-800">Edit Calon Siswa</h1>
                    </div>
                    <hr class="mb-2">
                    <div class="mt-4">
                    <form action="<?= base_url('siswa/editsiswa'); ?>" method="POST">
                        <input type="hidden" name="id" value="<?= $siswa['id'] ?>"> <div class="mb-3">
                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Nama</label>
                                <input type="text" name="nama" class="form-control" id="exampleFormControlInput1" placeholder="Nama" value="<?= $siswa['nama'] ?>">
                            </div>
                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Alamat</label>
                                <input type="text" name="alamat" class="form-control" id="exampleFormControlInput1" placeholder="Alamat" value="<?= $siswa['alamat'] ?>">
                            </div>
                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Jenis_Kelamin</label>
                                <input type="text" name="jenis_kelamin" class="form-control" id="exampleFormControlInput1" placeholder="Jenis_Kelamin" value="<?= $siswa['jenis_kelamin'] ?>">
                            </div>
                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Agama</label>
                                <input type="text" name="agama" class="form-control" id="exampleFormControlInput1" placeholder="Agama" value="<?= $siswa['agama'] ?>">
                            </div>
                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Asal Sekolah</label>
                                <input type="text" name="sekolah_asal" class="form-control" id="exampleFormControlInput1" placeholder="Asal Sekolah" value="<?= $siswa['sekolah_asal'] ?>">
                            </div>
                            <div class="mb-3">
                                <button type="submit" class="btn btn-dark">Simpan</button>
                            </div>
                        </form>
                    </div>
                    </div>
                    </div>
</body>